# aifinance.github.io is an italian blog talking about financial engineering applications
